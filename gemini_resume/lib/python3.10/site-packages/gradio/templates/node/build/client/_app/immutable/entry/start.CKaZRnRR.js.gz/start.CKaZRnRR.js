import { s } from "../chunks/client.Db55cSoU.js";
export {
  s as start
};
