import { z, _ } from "../chunks/2.CMLIkXPr.js";
export {
  z as component,
  _ as universal
};
